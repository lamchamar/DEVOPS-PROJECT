package org.enset.ensetbillingservice.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@NoArgsConstructor
@AllArgsConstructor

public class Customer {

// les parametres de la class Customer
    private String id;
    private String name;
    private  String email;


}

