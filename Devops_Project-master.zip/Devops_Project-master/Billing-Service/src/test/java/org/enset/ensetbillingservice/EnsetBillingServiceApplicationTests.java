package org.enset.ensetbillingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnsetBillingServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
